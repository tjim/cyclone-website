int *x;

int bar()
{
  int b;
  x = &b;
}
