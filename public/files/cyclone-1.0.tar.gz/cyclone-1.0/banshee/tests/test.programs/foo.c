int *x;

int main()
{
  int a;
  x = &a;
}
