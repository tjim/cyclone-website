#include "list.h"
#include "regexp.h"

DECLARE_LIST(annotations, regexp);
DEFINE_LIST(annotations, regexp);
