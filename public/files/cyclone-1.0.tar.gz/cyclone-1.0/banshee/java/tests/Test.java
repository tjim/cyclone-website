public class Test {
    public static void main(String[] args) {
	Test t1 = new Test();
	Test t2 = t1;
    }

}