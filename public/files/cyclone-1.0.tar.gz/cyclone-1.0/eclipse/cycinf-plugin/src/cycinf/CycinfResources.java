package cycinf;

import java.util.ListResourceBundle;

public final class CycinfResources extends ListResourceBundle {
	Object[][] contents = new Object[][] {}; // HMMM some resources
	// to localize?
	@Override
	protected Object[][] getContents() {
		return contents;
	}
}
