package cycinf.infstats;

public interface BelongsToInfstats {
	public abstract DirInfstats getOwningInfstats();
}
