package cycinf.cvars;

public interface Pretty {
	public abstract String prettyString();
}
