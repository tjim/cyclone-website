package cycinf.constraints;

import general.util.EqualByStringRepresentation;

public abstract class CNode extends EqualByStringRepresentation {
	@Override
	public abstract String toString();
}
