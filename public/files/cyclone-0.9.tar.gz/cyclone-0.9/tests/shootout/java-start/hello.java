// $Id: hello.java,v 1.2 2004/09/07 20:33:26 mwh Exp $
// http://www.bagley.org/~doug/shootout/

public class hello {
    public static void main(String args[]) {
	//@START
	System.out.print("hello world\n");
	//@END
    }
}
